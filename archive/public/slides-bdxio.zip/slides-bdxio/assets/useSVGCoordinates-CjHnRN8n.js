const n=1e3;const I=50,_=8;function e(t,s){return s===1?1e3/2:100+800*t/(s-1)}export{I as L,n as S,_ as T,e as g};
