import{r}from"./modules/vue-DRycbs9T.js";const i=r(!0);function e(){i.value=!i.value}export{i,e as t};
